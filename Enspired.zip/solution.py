import re

import utils
from room import Room

'''
Author: Adrian Valero Gimeno
Contact e-mail: adrianval96@gmail.com
Github: https://github.com/Adrianval96
'''



'''
This first part of the code will include the regex patterns used
throughout the code to identify the different elements of the map.

ChairPattern does not consider multiple chairs right next to each other 
(w/o spaces in-between) but is sufficient for the given example
'''

roomNamePattern = re.compile("\([a-z ]*\)", re.IGNORECASE)

chairPattern = re.compile("([CWPS])+")
# TODO sospecho que hay un problema con este shiftingwalls porque no pilla nunca la condicion
shiftingWallsPattern = re.compile(r"[\\/]+")
lowerWallPattern = re.compile("\+\-*\+")
normalWallsPattern = re.compile("([\|])")

#All rooms
in_house_rooms = []
#Only rooms being parsed
open_rooms = []
enqueued_rooms = []

room_count = 0

lineLimit = 50

#lineIndex = 0

lines_in_file = utils.file_len("rooms.txt")


def parse_file(filepath):
    """
    Parse the map of the house at a given filepath

    Parameters
    -----------
    filepath : str
        Filepath for file_object to be parsed

    Returns
    -------
    TBD
    """
    lineIndex = 1

    with open(filepath, 'r') as file_object:
        line = file_object.readline()

        initialiseRoomsOnTop(line)

        # print(currently_parsing_rooms)

        # print(all_rooms)
        # print(wall_positions)

        while line:

            # This method updates the room list in case there were any other rooms closing in last line
            addEnqueuedRooms()
            #print(open_rooms)
            # This checks if the line contains the name of any rooms and updates the dataset accordingly
            roomNamesInLine = findRoomNamesInLine(line)
            if len(roomNamesInLine) > 0:
                for name, index in roomNamesInLine:
                    name = name.strip("(")
                    name = name.strip(")")

                    # print("FLAG2")
                    print("Room name found: " + name + " in position: " + str(index))
                    this_room = getRoomFromPosition(index)
                    #print("Room where name is being added: ")
                    #print(this_room)
                    if this_room != -1:
                        this_room.setRoomName(name)
            chairsInLine = findChairsInLine(line)
            if (len(chairsInLine) > 0):
                for chair, index in chairsInLine:
                    # print(type, index)
                    # Here we will need to update each room accordingly,
                    # taking into account each of the walls and other bounds.
                    # print("FLAG3")
                    this_room = getRoomFromPosition(index)
                    # print("FLAG4")
                    # print(this_room)
                    # print(type)
                    # addChairToRoomCount(this_room, type)
                    if this_room != -1:
                        this_room.addChairToRoom(chair)

            checkforWallShifts(line)

            adjustFromLowerWalls(line, lineIndex)

            line = file_object.readline()

            lineIndex += 1

    printInfoAtTheEnd()


def createNewRoom(lb, rb):
    new_room = Room(lb, rb)
    in_house_rooms.append(new_room)
    open_rooms.append(new_room)

# Initial parsing to check how many rooms there are on top of the map, equal to the number of '+' elements minus 1
# These initial rooms are added to our room list, without a name for now.
def initialiseRoomsOnTop(line):
    wall_positions = []
    for match in re.finditer('\+', line):
        wall_positions.append(match.start())

    rooms_being_parsed = len(wall_positions) - 1
    for i in range(rooms_being_parsed):
        createNewRoom(wall_positions[i], wall_positions[i + 1])

    #print(wall_positions)
    #if lineIndex % 10 == 0:
    #    for room in in_house_rooms:
    #        print(room)


# N^2
def adjustFromLowerWalls(line, lineIndex):
    if lineIndex < 5:
        return

    if lineIndex == 12:
        print("PRINTING MATCHES FOR LOWER WALLS IN LINE 12:")
        for match in re.finditer(lowerWallPattern, line):

            print("Start: " + str(match.start()) + " and end: " + str(match.end()))

    for match in re.finditer(lowerWallPattern, line):
        start = match.start()
        end = match.end() - 1
        for room in open_rooms:
            lb, rb = room.getRoomBounds()
            if lineIndex in {8, 12, 17, 22, 31, 35, 44, 50}:
                print("Line: " + str(lineIndex))
                print("Current bounds:" + str(lb) + ", " + str(rb))
                print("Start and end of lower wall pattern:" + str(start) + ", " + str(end))

            # If the bounds match that means the room needs to be closed. If a new one must be open depends on next line
            if start == lb and end == rb:
                print("Line: " + str(lineIndex))
                print("Case 1 for lower wall. Closing room and opening a new one in next line.")
                print(room)
                room.finishParsing()
                open_rooms.remove(room)
                if lineIndex == lines_in_file:
                    break
                enqueued_rooms.append([start, end])
                break

                #TODO find out how to check next line to open a new room OR extend the bounds of the existing one
            # If bounds DO NOT match means that:
            # 1. The wall shifts from a '+' symbol position to another
            elif start == lb and end < rb:
                neighbor = findAdjacentRoom("left", room)
                #print("Line: " + str(lineIndex))
                print("Case 2 for lower wall. Moving to the right and updating neighbor / creating new room.")
                print(room)
                room.setLeftWall(end)
                if neighbor:
                    print("Neighbor found. Updating... ")
                    #print(neighbor)
                    neighbor.setRightWall(end)
                    #print("Neighbor after changes:")
                    #print(neighbor)
                else:
                    enqueued_rooms.append([start, end])
                print("Room after changes:")
                print(room)
                break

            elif start < lb and end == rb:
                neighbor = findAdjacentRoom("right", room)
                #print("Line: " + str(lineIndex))
                print("Case 3 for lower wall. Moving to the left and updating neighbor / creating new room.")
                print(room)
                room.setRightWall(start)
                if neighbor:
                    print("Neighbor found. Updating...")
                    #print(neighbor)
                    neighbor.setLeftWall(start)
                    #print("Neighbor after changes:")
                    #print(neighbor)
                else:
                    enqueued_rooms.append([start, end])
                print("Room after changes:")
                print(room)
                break
            else:
                print("Room not found in this iteration. Trying again...")
            #    if start == lb:
            #        room.setRightWall(end - 1)
            #    elif end == rb:
            #        room.setLeftWall(start)
    return False

def addEnqueuedRooms():
    if enqueued_rooms:
        for start, end in enqueued_rooms:
            createNewRoom(start, end)

# These next two methods could be united if I pass the pattern as a parameter
def findRoomNamesInLine(line):
    matches = []
    for match in re.finditer(roomNamePattern, line):
        obj = [match.group(), match.start()]
        matches.append(obj)
    return matches


# With this we will find the index in which each chair is positioned
# We will return a data object 'matches' containing the text (type of chair) as well as this index.
def findChairsInLine(line):
    matches = []
    for match in re.finditer(chairPattern, line):
        obj = [match.group(), match.start()]
        matches.append(obj)
    return matches



# TODO esto todavia no funciona
def checkforWallShifts(line):
    #print("Checking wall for shifts...")
    #print(re.match(shiftingWallsPattern, line))
    if re.match(shiftingWallsPattern, line):
        print("EUREKA")
        return updateWallPositionsOnShift(line)
    return None


# This method will update the wall positions of the room objects
def updateWallPositionsOnShift(line):
    for match in re.finditer(shiftingWallsPattern):
        if match.group() == '\\':
            shiftRoomsWall(1, getRoomFromPosition(match.start()), getRoomFromPosition(match.end()))
        elif match.group() == '\/':
            shiftRoomsWall(-1, getRoomFromPosition(match.start()), getRoomFromPosition(match.end()))


def getRoomFromPosition(pos):
    #print(pos)
    for room in open_rooms:
        print(room)
        if room.getLeftWall() <= pos < room.getRightWall():
            return room
    print("ERROR FINDING ROOM FROM POSITION")
    return -1

def findAdjacentRoom(direction, room):
    for candidate in open_rooms:
        if direction == "left":
            if room.getLeftWall() == candidate.getRightWall():
                return candidate
        if direction == "right":
            if room.getRightWall() == candidate.getLeftWall():
                return candidate
    return None


def shiftRoomsWall(shift, lr, rr):
    lr.setRightWall(lr.getRightWall() + shift)
    rr.setLeftWall(rr.getRightWall() + shift)

    print("Walls shifted!")


def printInfoAtTheEnd():
    roomList = []
    for room in in_house_rooms:
        roomList.append(room)
    roomList = sorted(roomList, key=lambda k: k.getRoomName())
    print("\nFinal list of rooms:")
    print(' \n'.join(map(str, roomList)))


def __main__():
    parse_file("rooms.txt")


__main__()
